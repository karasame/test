package jp.co.kuronekoyamato.apps.sampleApp.feature.pickup.viewModel

import android.app.Application
import android.content.Context
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import jp.co.kuronekoyamato.PickupTask
import jp.co.kuronekoyamato.PickupTaskStatus
import jp.co.kuronekoyamato.apps.sampleApp.core.barcode.BarcodeServiceProvider
import jp.co.kuronekoyamato.apps.sampleApp.core.barcode.cipherlab.BarcodeCallback
import jp.co.kuronekoyamato.apps.sampleApp.core.common.base.BaseViewModel
import jp.co.kuronekoyamato.apps.sampleApp.core.common.effect.CommonEffect
import jp.co.kuronekoyamato.apps.sampleApp.core.model.common.data.TaskList
import jp.co.kuronekoyamato.apps.sampleApp.core.model.taskList.data.TaskListTaskSubGroup
import jp.co.kuronekoyamato.apps.sampleApp.domain.pickup.useCase.CompletePickupUseCase
import jp.co.kuronekoyamato.apps.sampleApp.domain.pickup.useCase.GetPickupUseCase
import jp.co.kuronekoyamato.apps.sampleApp.feature.pickup.mapper.PickupTaskStateMapper
import jp.co.kuronekoyamato.apps.sampleApp.feature.pickup.state.PickupState
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

sealed class NavigationEvent {
    object NavigateToComplete : NavigationEvent()
}


@HiltViewModel
class PickupViewModel @Inject constructor(
    application: Application,
    private val getPickupUseCase: GetPickupUseCase,
    private val completePickupUseCase: CompletePickupUseCase,
    private val pickupTaskStateMapper: PickupTaskStateMapper,
// ): ViewModel() {
) : BaseViewModel<PickupState, CommonEffect>(), BarcodeCallback {

    override fun initialState(): PickupState {
        return PickupState()
    }

    private val _viewStates = MutableStateFlow(PickupState())
    val viewStates: StateFlow<PickupState> = _viewStates.asStateFlow()

    sealed class NavigationEvent {
        object NavigateToComplete : NavigationEvent()
    }
    private val _navigationEvent = MutableSharedFlow<NavigationEvent>()
    val navigationEvent = _navigationEvent.asSharedFlow()

    private val barcodeServiceProvider = BarcodeServiceProvider()
    private val appContext = application.applicationContext

    fun initializeScanner(context: Context) {
        barcodeServiceProvider.initialize(context, this)
    }

    override fun onScanScanned(barcode: String) {
        updatePickupDnpNo(barcode)
        viewModelScope.launch {
            _navigationEvent.emit(NavigationEvent.NavigateToComplete)
        }
    }

    override fun onCleared() {
        super.onCleared()
        println("结束扫码进程")
        barcodeServiceProvider.release(appContext)
    }

     fun getPickupTaskById(taskList: TaskList) {
        // // DBから取得
        // val summary = getPickupUseCase(taskList)
        // // stateに保持
        // val newState = pickupTaskStateMapper.map(summary)
        //
        // Log.d("taskList", summary.pickupTasks.size.toString())
        //
        // _viewStates.update { newState }

        safeLaunch(
            block = {
                getPickupUseCase(taskList)
            },
            onSuccess = { summary ->
                val newState = pickupTaskStateMapper.map(summary)
                updateState { newState }
            },
        )
    }

    fun selectTask(task: PickupTask) {
        _viewStates.value = _viewStates.value.copy(
            selectedTask = task,
            error = null,
        )
    }

    fun updateTaskStatus(status: PickupTaskStatus) {
        val currentTask = _viewStates.value.selectedTask ?: return
        val updatedTask = currentTask.copy(status = status)
        _viewStates.value = _viewStates.value.copy(selectedTask = updatedTask)
    }

    fun setError(message: String) {
        _viewStates.value = _viewStates.value.copy(error = message)
    }

    fun clearError() {
        _viewStates.value = _viewStates.value.copy(error = null)
    }

    fun completePickupTasks() {
        val taskIds = state.value.pickupTaskSubGroup.tasks.map { it.taskId }
        if (taskIds.isNotEmpty()) {
            safeLaunch(
                block = { completePickupUseCase.completePickup(taskIds) },
            )
        }
    }

    fun updatePickupDnpNo(dnpNo: String) {
        println("进入update函数")
        val taskIds = state.value.pickupTaskSubGroup.tasks.map { it.taskId }
        if (taskIds.isNotEmpty()) {
            println("判进if")
            safeLaunch(
                block = {
                    val task = state.value.pickupTaskSubGroup.tasks.first()
                    val newTask = task.copy(dnpNo = dnpNo)
                    val pickupTaskSubGroup = TaskListTaskSubGroup(tasks = listOf(newTask))
                    val newState = state.value.copy(pickupTaskSubGroup = pickupTaskSubGroup)
                    updateState { newState }
                    println(newState)
                },

            )
        }
    }
}

