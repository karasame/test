package jp.co.kuronekoyamato.apps.sampleApp.feature.pickup.screen

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import jp.co.kuronekoyamato.apps.sampleApp.core.designsystem.annotation.ThemePreviews
import jp.co.kuronekoyamato.apps.sampleApp.core.designsystem.catalog.data.ButtonMetadata
import jp.co.kuronekoyamato.apps.sampleApp.core.designsystem.component.divider.OwnLightDivider
import jp.co.kuronekoyamato.apps.sampleApp.core.designsystem.component.layout.OwnScaffold
import jp.co.kuronekoyamato.apps.sampleApp.core.designsystem.component.toggle.Toggle
import jp.co.kuronekoyamato.apps.sampleApp.core.designsystem.theme.CustomTheme
import jp.co.kuronekoyamato.apps.sampleApp.core.ui.R
import jp.co.kuronekoyamato.apps.sampleApp.feature.pickup.ui.InputBottomSection
import jp.co.kuronekoyamato.apps.sampleApp.feature.pickup.ui.PickupReportBottomButtonGroup
import jp.co.kuronekoyamato.apps.sampleApp.feature.pickup.ui.PickupTitle
import jp.co.kuronekoyamato.apps.sampleApp.feature.pickup.ui.PickupTopTab
import jp.co.kuronekoyamato.apps.sampleApp.feature.pickup.viewModel.PickupViewModel
import jp.co.kuronekoyamato.apps.sampleApp.feature.pickup.viewModel.PickupViewModel.NavigationEvent

/**
 * 集荷報告画面
 */
@Composable
fun PickupReportScreen(
    onCompleteClick: () -> Unit,
    modifier: Modifier = Modifier,
    viewModel: PickupViewModel = hiltViewModel(),
) {
    val context = LocalContext.current
    LaunchedEffect(viewModel) {
        viewModel.navigationEvent.collect { event ->
            when (event) {
                is NavigationEvent.NavigateToComplete -> {
                    onCompleteClick()
                }
            }
        }
    }

    LaunchedEffect(Unit) {
        viewModel.initializeScanner(context)
    }

    // 伝票番号
    var dnpNo by remember { mutableStateOf("") }

    val onValueChange: (String) -> Unit = { newDnpNo ->
        dnpNo = newDnpNo
    }

    // 画面
    PickUpReportScreenContent(
        modifier = modifier,
        onCompleteClick = {
            viewModel.updatePickupDnpNo(dnpNo)
            onCompleteClick()
        },
        onValueChange = onValueChange,
    )
}

@Composable
private fun PickUpReportScreenContent(
    modifier: Modifier = Modifier,
    onCompleteClick: () -> Unit = {},
    onValueChange: (String) -> Unit = {},
) {
    OwnScaffold(
        modifier = modifier,
        titleId = R.string.core_ui_pickup_report,
        bottomButtonBar = {
            PickupReportBottomButtonGroup()
        },
        content = {
            Column {
                PickupTopTab()
                PickupTitle(
                    titleContext = stringResource(id = R.string.core_ui_pickup_piece, 1),
                    subtextContext = "",
                    baggageInfoList = emptyList(),
                )
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    horizontalArrangement = Arrangement.spacedBy(
                        space = 12.dp,
                        alignment = Alignment.End,
                    ),
                ) {
                    Toggle(
                        initialSwitched = false,
                        onSwitchedChang = {},
                        isWide = true,
                        switchedOnText = stringResource(id = R.string.core_ui_pickup_shopping_on),
                        switchedOffText = stringResource(id = R.string.core_ui_pickup_shopping_off),
                    )
                    Toggle(
                        initialSwitched = false,
                        onSwitchedChang = {},
                        isWide = true,
                        switchedOnText = stringResource(id = R.string.core_ui_pickup_bring_on),
                        switchedOffText = stringResource(id = R.string.core_ui_pickup_bring_off),
                    )
                }
                OwnLightDivider()
                Spacer(Modifier.weight(1f))
                PickupReportInputBottomSection(
                    onCompleteClick = onCompleteClick,
                    onValueChange = onValueChange,
                )
            }
        },
    )
}

@Composable
private fun PickupReportInputBottomSection(
    modifier: Modifier = Modifier,
    onCompleteClick: () -> Unit = {},
    onValueChange: (String) -> Unit = {},
) {
    var inputText by remember { mutableStateOf("") }

    val buttonMetadataLists = listOf(
        ButtonMetadata(
            buttonType = "00",
            text = stringResource(id = R.string.core_ui_pickup_camera2),
            onclick = {},
        ),
    )
    InputBottomSection(
        modifier = modifier.padding(16.dp),
        text = stringResource(id = R.string.core_ui_track_number),
        inputText = inputText,
        buttonMetadataList = buttonMetadataLists,
        onValueChange = {
            inputText = it
            onValueChange(inputText)
        },
        onCompleteClick = onCompleteClick,
    )
}

@ThemePreviews
@Composable
private fun PickupReportScreenPreview() {
    CustomTheme {
        PickUpReportScreenContent(
            onCompleteClick = {},
            onValueChange = {},
        )
    }
}
